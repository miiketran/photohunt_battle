//
//  CircuitBoardViewController.swift
//  photohunt
//
//  Created by Michael Tran on 7/28/15.
//  Copyright © 2015 Michael Tran. All rights reserved.
//

import UIKit

class CircuitBoardViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

